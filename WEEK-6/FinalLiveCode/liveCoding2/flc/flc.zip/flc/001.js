/*
-----------------
RELATION FORECAST
-----------------
PROBLEM
=======
getRelationForecast adalah sebuah program sederhana untuk mendapatkan persentase
seberapa matching laki-laki dan perempuan berdasarkan nama.
Skala persentase adalah dari 0% - 100%.
Untuk setiap kriteria dibawah ini, lakukan perubahan skala.
- tambah 50 jika jumlah huruf a (atau A) di nama male dan female bertotal 5 atau lebih
- tambah 30 jika huruf depan male dan huruf belakang female sama
- tambah 10 jika nama female lebih panjang dari nama male
Otomatis 100 % jika:
  - nama male dan nama female kedua-keduanya memiliki 'kode'.
Ingat, skala tidak boleh melebihi 100%!

RULES
=====
- Dilarang menggunakan regex metode apapun
- Dilarang menggunakan sintaks .includes, .replace, .search.

*/

function getRelationForecast(maleName, femaleName) {
  // your code here
}

console.log(getRelationForecast('Indra', 'Indriani')); // 40%
console.log(getRelationForecast('Arakawa', 'Mirai')); // 50%
console.log(getRelationForecast('Osass', 'Siti')); // 0%
console.log(getRelationForecast('Joe', 'Jeanne')); // 10%
console.log(getRelationForecast('Nameless Koder', 'Do Nothing but kodeing')); // 100%
